import streamlit as st
st. set_page_config(layout="wide")
import numpy as np
import tensorflow as tf
import keras
from tensorflow.keras.preprocessing.image import load_img, img_to_array
import warnings
warnings.filterwarnings('ignore')

st.markdown("<h1 style='text-align: center; color: blue;'>Rakshit Walia Project</h1>", unsafe_allow_html=True)
st.markdown("<h4 style='text-align: center; color: skyblue;'>Dog Sentiment Analysis</h4>", unsafe_allow_html=True)

st.markdown("<h1 style='text-align: center; color: yellow ;'></h1>", unsafe_allow_html=True)
st.markdown("<h1 style='text-align: center; color: yellow ;'></h1>", unsafe_allow_html=True)

st.markdown("<h1 style='text-align: center; color: yellow ;'>⚡Model⚡</h1>", unsafe_allow_html=True)
st.markdown("<h1 style='text-align: center; color: yellow ;'></h1>", unsafe_allow_html=True)

from PIL import Image
newsize = (400, 400)
imh = Image.open('images/h_dog.jpeg')
imh = imh.resize(newsize)
ims = Image.open('images/s_dog.jpeg')
ims = ims.resize(newsize)
ima = Image.open('images/a_dog.jpeg')
ima = ima.resize(newsize)

col1, col2, col3, col4, col5, col6, col7 = st.columns([2, 3, 2, 3, 2, 3,2])
b1 = col2.button('Image 1 📇',key=1)
b2 = col4.button('Image 2 📇',key=2)
b3 = col6.button('Image 3 📇',key=3)  

col1, col2, col3, col4, col5 = st.columns([2,3,1,2,2])
st.markdown("<h1 style='text-align: center; color: yellow ;'></h1>", unsafe_allow_html=True)
if b1 :
    col2.image(imh, use_column_width = False)
    col4.write("Prediction:")
    col4.write("This dog is Happy")
    
if b2 :
    col2.image(ims, use_column_width = False)
    col4.write("Prediction:")
    col4.write("This dog is Sad")

if b3 :
    col2.image(ima, use_column_width = False)
    col4.write("Prediction:")
    col4.write("This dog is Angry")

st.markdown("<h1 style='text-align: center; color: yellow ;'></h1>", unsafe_allow_html=True)
st.markdown("<h1 style='text-align: center; color: yellow ;'></h1>", unsafe_allow_html=True)
st.markdown("<h6 style='color: skyblue;'>Description: </h6>", unsafe_allow_html=True)
st.write("The Dog Sentiment Analysis project is a cutting-edge application designed to analyze the emotions and" 
         "sentiments of dogs based on uploaded photos. This project leverages advanced machine learning algorithms" 
         "and computer vision techniques to accurately predict the emotional state of a dog captured in an image.")
st.write("Using this intuitive web-based platform, users can easily upload a photo of their dog and simply click the "
         "'Predict' button to obtain insights into their furry friend's emotional state. The underlying machine learning" 
         "model has been trained on a vast dataset of dog images encompassing various breeds, ages, and emotional expressions." 
         "This extensive training enables the model to provide accurate predictions across a wide range of dog photographs.")
st.write("The application utilizes deep learning algorithms to extract features and patterns from the uploaded image." 
         "These features are then processed through a sophisticated neural network model, which has learned to associate visual" 
         "cues with specific dog emotions. The model takes into account a multitude of factors, such as facial expressions, body "
         "language, and contextual cues, to make robust predictions about the dog's sentiment.")
st.write("The prediction results are displayed to the user, indicating the most likely emotion or sentiment exhibited by the dog" 
         "in the uploaded photo. The emotions recognized may include happiness, sadness and anger")

image = Image.open('images/arrowright.jpg')
#Create two columns with different width
col1, col2 = st.columns( [0.8, 0.2])
with col1:               # To display the header text using css style
    st.markdown(""" <style> .font {
     font-size:35px ; font-family: 'Cooper Black'; color: #FF0000;} 
    </style> """, unsafe_allow_html=True)
    st.markdown('<p class="font">Upload dog photo here...</p>', unsafe_allow_html=True)
    
with col2:               # To display brand logo
    st.image(image,  width=150)
        


#Add file uploader to allow users to upload photosS
uploaded_file = st.file_uploader("", type=['jpg','png','jpeg'])
col1, col2, col3 = st.columns([5,2,5])
b4 = col2.button('Predict Sentiment',key=4) 

if b4:
    
    if uploaded_file is not None:
        image = Image.open(uploaded_file)

        # Load the image and convert it to a Numpy array
        img = load_img(uploaded_file, target_size=(224, 224), grayscale=True)
        img_arr = img_to_array(img)

        # Reshape the array to match the input shape of the model
        img_arr = np.expand_dims(img_arr, axis=0)

        # Normalize the pixel values
        img_arr = img_arr / 255.0

        model = tf.keras.models.load_model('rakshit_dogEmotion_techdome21.h5')

        y_pred = model.predict(img_arr)
        
        res=np.argmax(y_pred, axis = 1)[0] 

        dictionary ={0: 'This dog is Angry', 1: 'This dog is Happy', 2: 'This dog is : Sad'}

        col1, col2, col3 = st.columns([3, 3, 3])
        st.markdown("<h1 style='text-align: center; color: yellow ;'></h1>", unsafe_allow_html=True)
        col2.image(image, use_column_width = True)
        col2.write(dictionary[res])
